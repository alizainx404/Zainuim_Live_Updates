#!/bin/bash
# ----------------------------------------------------------
#  ZAINUIM CORE LIBRARY (Path Fixed for Live OS)
# ----------------------------------------------------------

# --- 1. PATH RESOLUTION LOGIC ---
# Determine where the 'core' folder is relative to the script location.

# Option A: Called from inside user_cmds/ (Standard Dev Mode)
if [ -f "$(dirname "$0")/core/env.sh" ]; then
    CORE_DIR="$(dirname "$0")/core"

# Option B: Called from inside founder_cmds/ (Sibling directory fix)
elif [ -f "$(dirname "$0")/../zainuim/user_cmds/core/env.sh" ]; then
    CORE_DIR="$(dirname "$0")/../zainuim/user_cmds/core"

# Option C: Absolute Fallback (The "Baked" OS Path) 🦁
# Jab OS install ho jayega, ye files yahan milengi:
else
    CORE_DIR="/usr/share/.zainuim-internal-core"
fi

# --- 2. LOAD DEPENDENCIES ---
if [ -f "$CORE_DIR/env.sh" ]; then
    . "$CORE_DIR/env.sh"
    . "$CORE_DIR/security.sh"
else
    # Fallback if env.sh is missing, we continue but warn
    echo "Notice: Zainuim Core environment not loaded from $CORE_DIR"
fi

# --- 3. COLOR DEFINITIONS (Hardcoded for Stability) ---
C_GREEN="\033[1;32m"
C_YELLOW="\033[1;33m"
C_RED="\033[1;31m"
C_RESET="\033[0m"
C_LION="\033[1;33m\033[0m"

# --- 4. LOGGING FUNCTIONS ---
# Using 'echo -e' is essential for rendering colors in bash

zmsg() {
    echo -e "${C_GREEN}${C_LION}[Zainuim]${C_RESET} $1"
}

zwarn() {
    echo -e "${C_YELLOW}[Warning]${C_RESET} $1"
}

zerr() {
    echo -e "${C_RED}[Error]${C_RESET} $1"
    exit 1
}

# --- 5. INITIALIZATION ---
# Run security checks silently if the function exists
if command -v secure_hq >/dev/null 2>&1; then
    secure_hq 2>/dev/null
fi

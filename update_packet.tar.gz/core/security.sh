#!/bin/sh
# ----------------------------------------------------------
#  ZAINUIM SECURITY PROTOCOLS (Baked OS Edition)
# ----------------------------------------------------------

# 1. Require Root Access
require_root() {
    if [ "$(id -u)" -ne 0 ]; then
        echo "${C_RED}ERROR: This command requires Root privileges.${C_RESET}"
        echo "   Please use: sudo zainuim <command>"
        exit 1
    fi
}

# 2. Founder Exclusive Check (Updated for Vault)
founder_check() {
    # Ab hum check karenge ke kya Founder Key naye Vault mein hai?
    # Path: /usr/share/.zainuim-internal-core/founder.key
    
    if [ ! -f "/usr/share/.zainuim-internal-core/founder.key" ]; then
        echo "${C_RED}ACCESS DENIED: Founder Verification Failed.${C_RESET}"
        echo "   Missing Key: /usr/share/.zainuim-internal-core/founder.key"
        echo "   This tool is restricted to Ali Zain."
        exit 1
    fi
}

# 3. Lockdown Mode (Auto-fix permissions)
secure_hq() {
    # Naye Core Vault ko lock karein (700 = Sirf Malik khol sake)
    # Ye ensure karega ke user kabhi is folder mein na ghus paye
    if [ -d "/usr/share/.zainuim-internal-core" ]; then
        chmod 700 "/usr/share/.zainuim-internal-core" 2>/dev/null
    fi
    
    # Founder key ko bhi read-only bana dein (400)
    if [ -f "/usr/share/.zainuim-internal-core/founder.key" ]; then
        chmod 400 "/usr/share/.zainuim-internal-core/founder.key" 2>/dev/null
    fi
}
#!/bin/bash

#  ZAINUIM ENVIRONMENT (Variables)

# System Identity
export Z_NAME="Zainuim OS"
export Z_VERSION="zainuim-os-v1"
export Z_CODENAME="Calm Outside | Code Inside"
export Z_FOUNDER="Ali Zain"

# Paths (Dynamic: Works in Dev & Production)
# This logic checks if the OS is installed or running from Dev folder
if [ -d "/lib/zainuim" ]; then
    export Z_ROOT="/lib/zainuim"
else
    export Z_ROOT="$HOME/Zainuim_OS/rootfs/lib/zainuim"
fi

export Z_USER_HQ="$Z_ROOT/user_cmds"
export Z_FOUNDER_HQ="$Z_ROOT/founder_cmds"
export Z_SYS_HQ="$Z_ROOT/system_cmds"
export Z_SYS_SCRIPTS="$Z_ROOT/system_scripts"
export Z_ASSETS="$Z_ROOT/assets"
export Z_THEMES="$Z_ASSETS/themes"
export Z_WALLPAPERS="$Z_ASSETS/wallpapers"
export Z_BIN="/bin/zainuim"